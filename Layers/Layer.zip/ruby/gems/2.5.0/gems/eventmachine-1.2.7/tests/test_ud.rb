require 'em_test_helper'

class TestUserDefinedEvents < Test::Unit::TestCase

  def test_a
  end

end
