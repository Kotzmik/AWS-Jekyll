module Concurrent
  VERSION      = '1.1.5'
end
