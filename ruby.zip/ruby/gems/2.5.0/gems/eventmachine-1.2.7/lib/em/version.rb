module EventMachine
  VERSION = "1.2.7"
end
